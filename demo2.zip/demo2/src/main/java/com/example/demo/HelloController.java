package com.example.demo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



//@Controller
@RestController

@RequestMapping("/api/student")
public class HelloController {
	
	
	@GetMapping("/hi")
	public String sayHello()
	{
		return "Welcom to Spring boot";
	}

	@Autowired 
	StudentService service;
	
	@GetMapping()
	
	public List<Student> getStudents()
	{
		
	return service.getAllstudents();
	}
	
	
	@GetMapping("/{stuid}")
	public Student getStudentById(@PathVariable("stuid") Integer stuid){
	return service.getStudentById(stuid);
	}
	

	@PostMapping
	public String insertStudent(@RequestBody Student student){
	service.addStudent(student);
	return "inserted";
	}
	/*
	@Autowired
	StudentRepository studentrepository;
	@GetMapping("/getstudents")
	public List<Student> getAllStudents(){
		List<Student> allStudentlist = studentrepository.findAll();
		return allStudentlist;
		
	}
	  
	@GetMapping("/getstud/{id}")
	public Student getStudentbyId(@PathVariable(value = "studid") Integer studid)
      
	{
		Student student = studentrepository.findById(studid).get();
		
		return student;	
	}*/
	
}
