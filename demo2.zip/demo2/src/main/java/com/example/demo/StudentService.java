package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class StudentService {

	@Autowired
	StudentRepository sturepo;
	public void addStudent(Student stu) {
		
	sturepo.save(stu);
	}
	public List<Student> getAllstudents(){
	return sturepo.findAll();
	}
	
	public Student getStudentById( Integer stuid)
	{
		return sturepo.findById(stuid).get();
		
		
	}
}

