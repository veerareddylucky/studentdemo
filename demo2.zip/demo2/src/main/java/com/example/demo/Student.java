package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Student_details")
public class Student {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)	
	    private Integer stuid;
	    
	    @Column(name = "stuname", nullable = false)
	    private String stuname;
	    
	    @Column(name = "grade", nullable = false)
	    private String grade;

	    public Student()
	    {}
	
	    public Student(Integer stuid, String stuname, String grade) {
			super();
			this.stuid = stuid;
			this.stuname = stuname;
			this.grade = grade;
		}


		


		public Integer getStuid() {
			return stuid;
		}


		public void setStuid(Integer stuid) {
			this.stuid = stuid;
		}


		public String getStuname() {
			return stuname;
		}


		public void setStuname(String stuname) {
			this.stuname = stuname;
		}


		public String getGrade() {
			return grade;
		}


		public void setGrade(String grade) {
			this.grade = grade;
		}
	    
	    
	    
		@Override
		public String toString() {
			return "Student [stuid=" + stuid + ", stuname=" + stuname + ", grade=" + grade + "]";
		}

		public String get() {
			// TODO Auto-generated method stub
			return "Student [stuid=" + stuid + ", stuname=" + stuname + ", grade=" + grade + "]";
		}
	    
	    
}
